# IFT 301 assignment solution using python pandas and matplot libary
